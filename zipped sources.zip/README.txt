Todo:
* packages
* javadoc
* clean up the code in general
* dataflows